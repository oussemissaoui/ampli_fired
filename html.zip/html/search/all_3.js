var searchData=
[
  ['hero',['Hero',['../structHero.html',1,'']]]
];
