var searchData=
[
  ['icon',['icon',['../structicon.html',1,'']]],
  ['image',['image',['../structimage.html',1,'']]],
  ['initperso',['initPerso',['../player_8c.html#a00b6d5150efe88327bf8bf02770e04fc',1,'player.c']]],
  ['input',['Input',['../structInput.html',1,'']]]
];
