var searchData=
[
  ['scoreinfo',['ScoreInfo',['../structScoreInfo.html',1,'']]]
];
