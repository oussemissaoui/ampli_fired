var searchData=
[
  ['player_2ec',['player.c',['../player_8c.html',1,'']]]
];
