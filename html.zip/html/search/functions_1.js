var searchData=
[
  ['initperso',['initPerso',['../player_8c.html#a00b6d5150efe88327bf8bf02770e04fc',1,'player.c']]]
];
