var searchData=
[
  ['afficherperso',['afficherPerso',['../player_8c.html#ae0e17ffd99e4414075778aa3d42c8fe0',1,'player.c']]],
  ['animerperso',['animerPerso',['../player_8c.html#ae80a28fc0366b4acf5bb4587589f0b6b',1,'player.c']]]
];
